import Image from "next/image";
import Link from "next/link";

type BrandLogoProps = {
  showWordmark?: boolean;
  size?: "sm" | "md" | "lg";
  href?: string;
  className?: string;
};

const sizes = {
  sm: { img: 40, text: "text-sm", sub: "text-[0.62em]" },
  md: { img: 48, text: "text-base", sub: "text-[0.62em]" },
  lg: { img: 80, text: "text-2xl", sub: "text-[0.55em]" },
};

export function BrandLogo({
  showWordmark = true,
  size = "md",
  href = "/",
  className = "",
}: BrandLogoProps) {
  const s = sizes[size];
  const content = (
    <>
      <Image
        src="/brand/logo.png"
        alt="CrewPlay"
        width={s.img}
        height={s.img}
        className="h-auto w-auto shrink-0 object-contain"
        style={{ width: s.img, height: s.img }}
        priority
      />
      {showWordmark && (
        <span className={`font-bold leading-tight text-brand-900 ${s.text}`}>
          CrewPlay
          <span className={`block font-semibold tracking-wide text-brand-600 ${s.sub}`}>
            運動媒合平台
          </span>
        </span>
      )}
    </>
  );

  if (!href) {
    return <div className={`flex items-center gap-2.5 ${className}`}>{content}</div>;
  }

  return (
    <Link href={href} className={`flex items-center gap-2.5 ${className}`}>
      {content}
    </Link>
  );
}

export function BrandLogoMark({ size = 64 }: { size?: number }) {
  return (
    <Image
      src="/brand/logo.png"
      alt="CrewPlay"
      width={size}
      height={size}
      className="object-contain"
      style={{ width: size, height: size }}
      priority
    />
  );
}

import Link from "next/link";

import { BrandLogo } from "@/components/BrandLogo";

import { getAllTeams } from "@/lib/teams";



export default async function HomePage() {

  const teams = await getAllTeams();

  const sports = [...new Set(teams.map((t) => t.sport).filter(Boolean))].slice(0, 6);



  return (

    <div>

      <section className="brand-hero relative overflow-hidden text-white">

        <div className="pointer-events-none absolute -right-16 top-8 opacity-10">

          <BrandLogo href="" showWordmark={false} size="lg" />

        </div>

        <div className="mx-auto max-w-6xl px-4 py-16 sm:py-24">

          <BrandLogo href="" size="lg" className="[&_span]:text-white [&_span_span]:text-brand-200" />

          <p className="mt-8 text-sm font-semibold uppercase tracking-[0.2em] text-brand-200">Find Your Play</p>

          <h1 className="mt-4 max-w-2xl text-4xl font-bold leading-tight sm:text-5xl">

            找到你的運動夥伴

            <br />

            隨時開打

          </h1>

          <p className="mt-6 max-w-xl text-lg text-brand-100/95">

            全台揪團場地一站瀏覽，團主開團、場主刊登、線上預約，讓運動更容易成團。

          </p>

          <div className="mt-10 flex flex-wrap gap-3">

            <Link href="/teams" className="btn-primary bg-white text-brand-900 hover:bg-brand-50">

              立即找團 ({teams.length} 團)

            </Link>

            <Link href="/join/host" className="btn-outline">

              我要開團

            </Link>

            <Link href="/join/venue" className="btn-outline">

              場主刊登

            </Link>

          </div>

        </div>

      </section>



      <section className="mx-auto max-w-6xl px-4 py-16">

        <h2 className="text-2xl font-bold text-brand-900">我們在做的事很簡單</h2>

        <p className="mt-2 text-slate-600">讓運動更容易成團</p>

        <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">

          {[

            "一鍵瀏覽附近揪團，想動就動",

            "依運動、縣市、團名搜尋",

            "羽球、桌球、排球等多元項目",

            "線上預約＋金流，減少放鳥",

          ].map((text) => (

            <li

              key={text}

              className="rounded-2xl border border-brand-100 bg-white p-5 text-sm text-slate-700 shadow-sm"

            >

              {text}

            </li>

          ))}

        </ul>

      </section>



      {sports.length > 0 && (

        <section className="border-t border-brand-100 bg-white py-12">

          <div className="mx-auto max-w-6xl px-4">

            <h2 className="text-lg font-bold text-brand-900">依運動探索</h2>

            <div className="mt-4 flex flex-wrap gap-2">

              {sports.map((sport) => (

                <Link

                  key={sport}

                  href={`/teams?sport=${encodeURIComponent(sport)}`}

                  className="rounded-full border border-brand-200 bg-brand-50 px-4 py-2 text-sm font-medium text-brand-800 hover:bg-brand-100"

                >

                  {sport}

                </Link>

              ))}

            </div>

          </div>

        </section>

      )}

    </div>

  );

}


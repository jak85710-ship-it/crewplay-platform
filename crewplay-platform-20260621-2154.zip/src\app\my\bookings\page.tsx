import Link from "next/link";
import { listBookings } from "@/lib/bookings";

export default async function MyBookingsPage() {
  const bookings = await listBookings();
  const mine = bookings.slice(0, 50);

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">我的預約</h1>
          <p className="mt-2 text-sm text-slate-600">綁定 LINE 帳號以便追蹤預約</p>
        </div>
        <Link
          href="/api/auth/line/login"
          className="rounded-xl bg-[#06C755] px-4 py-2.5 text-sm font-semibold text-white"
        >
          LINE 登入
        </Link>
      </div>

      {mine.length === 0 ? (
        <p className="mt-10 rounded-2xl border border-dashed p-8 text-center text-slate-500">
          尚無預約紀錄。<Link href="/teams" className="text-brand-600 underline">去找團</Link>
        </p>
      ) : (
        <ul className="mt-8 space-y-4">
          {mine.map((b) => (
            <li key={b.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-semibold">{b.guest_name}</span>
                <span
                  className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${
                    b.status === "paid"
                      ? "bg-green-100 text-green-800"
                      : b.status === "pending_payment"
                        ? "bg-amber-100 text-amber-800"
                        : "bg-slate-100 text-slate-600"
                  }`}
                >
                  {b.status}
                </span>
              </div>
              <p className="mt-2 text-sm text-slate-600">
                {b.slots} 人 · NT$ {b.amount} · {b.merchant_trade_no}
              </p>
              <p className="mt-1 text-xs text-slate-400">{b.created_at}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
